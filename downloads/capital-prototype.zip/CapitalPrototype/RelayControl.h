#pragma once
#include <stdint.h>
#include <math.h>

namespace capital {
struct Timing {
  uint32_t lead = 800, overlap = 300, endHold = 300, allOff = 2600;
  uint32_t total() const { return lead + overlap + endHold + allOff; }
  uint32_t active() const { return lead + overlap + endHold; }
};
struct Outputs { bool big, small; };
inline int32_t signed24(uint32_t word) {
  word &= 0xFFFFFFUL;
  return (word & 0x800000UL) ? static_cast<int32_t>(word | 0xFF000000UL) : static_cast<int32_t>(word);
}
inline bool validCounts(int32_t value) { return value > -8388592L && value < 8388591L; }
inline bool calibrationFactor(float zero, float loaded, float knownN, float &result) {
  if (!isfinite(zero) || !isfinite(loaded) || !isfinite(knownN) || knownN <= 0 || fabsf(loaded - zero) < 128) return false;
  result = (loaded - zero) / knownN;
  return isfinite(result) && fabsf(result) > 0.000001f;
}

class RelayControl {
public:
  Timing timing;
  float onN = 1.2f, offN = 0.5f, fullScaleIncrementN = 10.0f;
  uint16_t cycles = 0, tailCycles = 0;
  void stop() {
    pressed_ = active_ = hasCycle_ = pending_ = high_ = low_ = tailScheduled_ = false;
    tails_ = 0; force_ = 0; cycles = tailCycles = 0;
  }
  bool sample(uint32_t now, float forceN) {
    if (!isfinite(forceN)) { stop(); return false; }
    force_ = forceN;
    if (forceN > onN) { if (!high_) { high_ = true; highSince_ = now; } }
    else high_ = false;
    if (forceN < offN) { if (!low_) { low_ = true; lowSince_ = now; } }
    else low_ = false;
    if (!pressed_ && high_ && elapsed(now, highSince_) >= 100) {
      pressed_ = true; pressedSince_ = now; tails_ = 0; tailScheduled_ = false;
      if (!hasCycle_ || elapsed(now, started_) >= timing.total()) start(now, false);
      else pending_ = true; // At most one queued short load.
    }
    if (pressed_ && low_ && elapsed(now, lowSince_) >= 150) {
      const bool sustained = elapsed(now, pressedSince_) >= 1200;
      pressed_ = false;
      if (sustained) {
        pending_ = false; tails_ = 2; tailScheduled_ = true;
        const uint32_t delayFromStart = timing.total() + 1200;
        const uint32_t age = elapsed(now, started_);
        const uint32_t wait = hasCycle_ && age < delayFromStart ? delayFromStart - age : 0;
        nextTail_ = now + (wait > 900 ? wait : 900);
      } else { tails_ = 0; tailScheduled_ = false; }
    }
    return true;
  }
  void tick(uint32_t now) {
    if (active_ && elapsed(now, started_) >= timing.active()) active_ = false;
    const bool ready = !hasCycle_ || elapsed(now, started_) >= timing.total();
    if (pending_ && ready) { pending_ = false; start(now, false); }
    else if (pressed_ && (!hasCycle_ || elapsed(now, started_) >= period())) start(now, false);
    else if (!pressed_ && tails_ && tailScheduled_ && due(now, nextTail_) && ready) {
      start(now, true); --tails_; tailScheduled_ = tails_ > 0;
      nextTail_ = now + timing.total() + 2700;
    }
    if (!pressed_ && !pending_ && !tails_ && !active_ && hasCycle_ && elapsed(now, started_) >= timing.total()) hasCycle_ = false;
  }
  Outputs outputs(uint32_t now) const {
    if (!active_) return {false, false};
    const uint32_t age = elapsed(now, started_);
    return {age < timing.lead + timing.overlap,
            age >= timing.lead && age < timing.active()};
  }
  uint32_t period() const {
    const float denominator = fullScaleIncrementN - onN;
    float u = denominator > 0 ? (force_ - onN) / denominator : 1;
    if (u < 0) u = 0; if (u > 1) u = 1;
    return timing.total() + static_cast<uint32_t>(2700 * (1 - u));
  }
  bool pressed() const { return pressed_; }
  uint8_t tails() const { return tails_; }
private:
  bool pressed_ = false, active_ = false, hasCycle_ = false, pending_ = false;
  bool high_ = false, low_ = false, tailScheduled_ = false;
  uint8_t tails_ = 0;
  float force_ = 0;
  uint32_t started_ = 0, pressedSince_ = 0, highSince_ = 0, lowSince_ = 0, nextTail_ = 0;
  static uint32_t elapsed(uint32_t now, uint32_t then) { return now - then; }
  static bool due(uint32_t now, uint32_t deadline) { return static_cast<int32_t>(now - deadline) >= 0; }
  void start(uint32_t now, bool tail) { started_ = now; active_ = hasCycle_ = true; ++cycles; if (tail) ++tailCycles; }
};
}
