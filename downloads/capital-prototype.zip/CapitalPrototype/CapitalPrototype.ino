/*
  Bench implementation for the flat-top capital, NOT a structural force instrument.
  Board: classic Arduino Nano 5V / ATmega328P.
  Sensor: four-wire full-bridge strain-gauge force cell -> HX711 A-channel.
  D3=DT, D2=SCK, D9=M0 driver EN, D10=buffer -> eight S driver ENs.
  Pololu4035 DRV8874: PMODE=5V, IMODE=GND, IN2=GND, SLEEP=5V.
  IN1 is the active-HIGH command; current is set by each board VREF resistor.
  D4=wire-AND open-drain FAULT (4.7k pull-up), D5=NC thermal loop to GND.
  An open thermal loop is a fault. Emergency stop physically cuts driver VIN.
  No watchdog or certified safety function; supervised low-voltage bench only.
  No coil is powered by the Nano. No pin here sets physical coil current.

  Serial 115200, newline: t=baseline; k <known_increment_N>=calibrate;
  p <on_N> <off_N>=thresholds; a=arm at baseline; x=immediate stop; ?=help.
  Example calibration load:1kg increment =9.80665N (not a prescribed sensor range).
  After restart calibration factor is retained, but a fresh manual baseline is required.
*/
#include <Arduino.h>
#include <EEPROM.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "RelayControl.h"
#include "Hx711Reader.h"

const uint8_t M0_EN = 9, S_EN = 10, DRIVER_FAULT = 4, THERMAL_LOOP = 5;
const float MAX_ADDED_N = 20.0f, MIN_ADDED_N = -3.0f;
bool hardwareHealthy() {
  return digitalRead(DRIVER_FAULT) == HIGH && digitalRead(THERMAL_LOOP) == LOW;
}
const uint16_t SENSOR_TIMEOUT_MS = 500;
const uint8_t CAPTURE_SAMPLES = 32;
const uint32_t CAL_MAGIC = 0x43504631UL;
struct StoredCalibration { uint32_t magic, scaleBits, check; };
enum CaptureMode : uint8_t { NONE, BASELINE, CALIBRATION };
void beginCapture(CaptureMode mode, uint32_t now);

Hx711Reader adc;
capital::RelayControl relay;
bool armed = false, fault = false, zeroValid = false, calibrated = false, haveSample = false;
bool outputBig = false, outputSmall = false;
float countsPerN = 0, baselineNoiseCounts = 0, forceN = 0, filteredN = 0;
int32_t zeroCounts = 0, lastRaw = 0;
uint32_t lastSampleAt = 0, lastFilterAt = 0, lastLogAt = 0, captureStartedAt = 0;
CaptureMode capture = NONE;
uint8_t captureCount = 0;
float captureMean = 0, captureM2 = 0, calibrationKnownN = 0;
char command[48];
uint8_t commandLength = 0;
bool discardCommand = false;

void writeOutputs(bool big, bool small) {
  if (big != outputBig) { digitalWrite(M0_EN, big ? HIGH : LOW); outputBig = big; }
  if (small != outputSmall) { digitalWrite(S_EN, small ? HIGH : LOW); outputSmall = small; }
}
void stopControl() { armed = false; relay.stop(); writeOutputs(false, false); }
void trip(const __FlashStringHelper *reason) {
  stopControl(); capture = NONE; zeroValid = false;
  if (!fault) { fault = true; Serial.print(F("FAULT: ")); Serial.println(reason); }
}
void loadCalibration() {
  StoredCalibration s; EEPROM.get(0, s);
  if (s.magic != CAL_MAGIC || s.check != (s.magic ^ s.scaleBits ^ 0xA5C31F0DUL)) return;
  memcpy(&countsPerN, &s.scaleBits, sizeof(countsPerN));
  calibrated = isfinite(countsPerN) && fabsf(countsPerN) > 0.000001f;
}
void saveCalibration() {
  StoredCalibration s; s.magic = CAL_MAGIC;
  memcpy(&s.scaleBits, &countsPerN, sizeof(countsPerN));
  s.check = s.magic ^ s.scaleBits ^ 0xA5C31F0DUL;
  EEPROM.put(0, s);
}
void beginCapture(CaptureMode mode, uint32_t now) {
  stopControl();
  if (!hardwareHealthy()) { trip(F("driver FAULT or open thermal loop")); return; }
  fault = false; capture = mode; captureCount = 0;
  captureMean = captureM2 = 0; captureStartedAt = now;
  if (mode == BASELINE) zeroValid = false;
  Serial.println(mode == BASELINE ? F("Keep the intended baseline load steady; collecting32 samples.") : F("Keep the known ADDED force steady; collecting32 samples."));
}
void finishCapture() {
  const float sd = sqrtf(captureM2 > 0 ? captureM2 / (CAPTURE_SAMPLES - 1) : 0);
  if (capture == BASELINE) {
    zeroCounts = static_cast<int32_t>(lroundf(captureMean)); baselineNoiseCounts = sd;
    zeroValid = true; filteredN = forceN = 0;
    Serial.print(F("Baseline counts=")); Serial.print(zeroCounts);
    Serial.print(F(" sigmaCounts=")); Serial.println(sd, 2);
  } else {
    float candidate = 0;
    if (!capital::calibrationFactor(static_cast<float>(zeroCounts), captureMean, calibrationKnownN, candidate)) {
      Serial.println(F("Calibration rejected: bad force or span<128 counts.")); capture = NONE; return;
    }
    if (sd / fabsf(candidate) > calibrationKnownN * .02f) {
      Serial.println(F("Calibration rejected: keep load stable / fix noise.")); capture = NONE; return;
    }
    countsPerN = candidate; calibrated = true; saveCalibration();
    Serial.print(F("countsPerN=")); Serial.println(countsPerN, 4);
    Serial.println(F("Remove the calibration increment. Return to baseline before 'a'."));
  }
  capture = NONE;
}
void acceptSample(int32_t raw, uint32_t now) {
  haveSample = true; lastSampleAt = now; lastRaw = raw;
  if (capture != NONE) {
    ++captureCount; const float delta = raw - captureMean;
    captureMean += delta / captureCount; captureM2 += delta * (raw - captureMean);
    if (captureCount == CAPTURE_SAMPLES) finishCapture();
  }
  if (calibrated && zeroValid) {
    forceN = static_cast<float>(raw - zeroCounts) / countsPerN;
    if (!isfinite(forceN)) { trip(F("nonfinite force")); return; }
    if (armed && (forceN > MAX_ADDED_N || forceN < MIN_ADDED_N)) {
      trip(F("force outside bench increment range")); return;
    }
    const uint32_t dt = now - lastFilterAt;
    const float alpha = static_cast<float>(dt) / (80.0f + dt);
    filteredN += alpha * (forceN - filteredN); lastFilterAt = now;
    if (armed && !relay.sample(now, filteredN)) trip(F("invalid filtered force"));
  } else lastFilterAt = now;
}
bool parseFloatArg(char *text, float &out, char **after = nullptr) {
  if (!text) return false; char *end;
  const double value = strtod(text, &end);
  if (end == text || !isfinite(value)) return false;
  out = static_cast<float>(value); if (after) *after = end;
  return isfinite(out);
}
void help() {
  Serial.println(F("t baseline | k <added_N> calibration | p <on_N> <off_N>"));
  Serial.println(F("r <2800..10000> fastest cycle ms (OFF while changing)"));
  Serial.println(F("a arm | x stop | ? help. No auto-zero/auto-arm. D4=FAULT D5=NC thermal."));
  Serial.println(F("CSV:raw,delta_N,filtered_N,armed,M0,S,fault"));
}
void handleCommand(char *line, uint32_t now) {
  if (!line[0]) return;
  const char op = line[0] >= 'A' && line[0] <= 'Z' ? line[0] + ('a' - 'A') : line[0];
  if (op == 'x') { stopControl(); capture = NONE; Serial.println(F("STOPPED")); }
  else if (op == 't') beginCapture(BASELINE, now);
  else if (op == 'k') {
    float value;
    if (!zeroValid || !parseFloatArg(line + 1, value) || value <= 0 || value > 10) { Serial.println(F("First 't', then 'k <ADDED force 0..10 N>'.")); return; }
    calibrationKnownN = value; beginCapture(CALIBRATION, now);
  } else if (op == 'p') {
    float on, off; char *next;
    if (!parseFloatArg(line + 1, on, &next) || !parseFloatArg(next, off) || off <= 0 || on <= off || on >= relay.fullScaleIncrementN) {
      Serial.println(F("Need 0<off<on<10N (change fullScaleIncrementN for other bench range).")); return;
    }
    stopControl(); relay.onN = on; relay.offN = off;
    Serial.println(F("Thresholds set. Check noise then 'a' to arm."));
  } else if (op == 'r') {
    float value;
    if (!parseFloatArg(line + 1, value) || value < 2800 || value > 10000) {
      Serial.println(F("Need 2800..10000ms; use 4000 initially. 2800 requires physical tests.")); return;
    }
    stopControl(); relay.timing.allOff = static_cast<uint32_t>(value) - relay.timing.active();
    Serial.println(F("Minimum cycle updated; 'a' to re-arm at baseline."));
  } else if (op == 'a') {
    if (!hardwareHealthy() || capture != NONE || fault || !calibrated || !zeroValid || !haveSample || now - lastSampleAt > SENSOR_TIMEOUT_MS) {
      Serial.println(F("Not ready: check ADC, 't' baseline, 'k' calibration, fault.")); return;
    }
    if (relay.onN <= 5 * baselineNoiseCounts / fabsf(countsPerN)) {
      Serial.println(F("Threshold too close to baseline noise. Fix wiring / increase 'p'.")); return;
    }
    if (fabsf(filteredN) >= relay.offN) { Serial.println(F("Return to intended baseline before arming.")); return; }
    relay.stop(); armed = true; Serial.println(F("ARMED: digital EN timing only; current set by external drivers."));
  } else help();
}
void readCommands(uint32_t now) {
  uint8_t budget = 16; // Continuous serial traffic must not starve output timing / sensor timeout.
  while (budget-- && Serial.available()) {
    const char c = Serial.read();
    if (c == '\r') continue;
    if (discardCommand) { if (c == '\n') { discardCommand = false; commandLength = 0; } continue; }
    if (c == '\n') { command[commandLength] = 0; handleCommand(command, now); commandLength = 0; break; }
    else if (commandLength < sizeof(command) - 1) command[commandLength++] = c;
    else { stopControl(); commandLength = 0; discardCommand = true; Serial.println(F("Command too long; stopped.")); }
  }
}
void setup() {
  digitalWrite(M0_EN, LOW); digitalWrite(S_EN, LOW);
  pinMode(M0_EN, OUTPUT); pinMode(S_EN, OUTPUT); // External pull-downs are still required during reset.
  pinMode(DRIVER_FAULT, INPUT_PULLUP); pinMode(THERMAL_LOOP, INPUT_PULLUP);
  Serial.begin(115200); adc.begin(); loadCalibration(); help();
  Serial.println(F("Outputs OFF. Baseline is NOT taken automatically."));
}
void loop() {
  uint32_t now = millis();
  if ((armed || capture != NONE) && !hardwareHealthy()) trip(F("driver FAULT or open thermal loop"));
  int32_t raw = 0;
  const Hx711Reader::Result result = adc.poll(raw);
  if (result == Hx711Reader::OK) acceptSample(raw, now);
  else if (result == Hx711Reader::BAD_FRAME || result == Hx711Reader::SATURATED) {
    if (armed || capture != NONE) trip(result == Hx711Reader::BAD_FRAME ? F("ADC frame/DOUT stuck") : F("ADC saturation"));
  }
  readCommands(now);
  now = millis();
  if (capture != NONE && now - captureStartedAt > 8000) trip(F("capture timeout"));
  if (armed) {
    if (!haveSample || now - lastSampleAt > SENSOR_TIMEOUT_MS) trip(F("no fresh ADC data for500ms"));
    else { relay.tick(now); const capital::Outputs out = relay.outputs(now); writeOutputs(out.big, out.small); }
  } else writeOutputs(false, false);
  if (now - lastLogAt >= 100 && haveSample && Serial.availableForWrite() >= 60) {
    lastLogAt = now;
    Serial.print(lastRaw); Serial.print(','); Serial.print(forceN, 2); Serial.print(',');
    Serial.print(filteredN, 2); Serial.print(','); Serial.print(armed); Serial.print(',');
    Serial.print(outputBig); Serial.print(','); Serial.print(outputSmall); Serial.print(','); Serial.println(fault);
  }
}
