#pragma once
#include <Arduino.h>
#include <util/atomic.h>
#include "RelayControl.h"

// Classic 5V ATmega328P Nano / Uno only. A-channel, gain128, exactly25 clocks.
class Hx711Reader {
public:
  enum Result : uint8_t { NOT_READY, OK, BAD_FRAME, SATURATED };
  void begin() {
    digitalWrite(2, LOW); pinMode(2, OUTPUT);
    pinMode(3, INPUT_PULLUP); // Unplugged DOUT normally remains NOT_READY.
  }
  Result poll(int32_t &counts) {
    if (digitalRead(3) != LOW) return NOT_READY;
    uint32_t bits = 0;
    // Protect only each HIGH pulse; allow UART interrupts during LOW intervals.
    // Masking all25 clocks together can lose serial bytes at115200baud.
    for (uint8_t i = 0; i < 24; ++i) {
      ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        digitalWrite(2, HIGH); delayMicroseconds(1);
        bits = (bits << 1) | (digitalRead(3) == HIGH ? 1UL : 0UL);
        digitalWrite(2, LOW);
      }
      delayMicroseconds(1);
    }
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
      digitalWrite(2, HIGH); delayMicroseconds(1);
      digitalWrite(2, LOW);
    }
    delayMicroseconds(1);
    if (digitalRead(3) != HIGH) return BAD_FRAME;
    counts = capital::signed24(bits);
    return capital::validCounts(counts) ? OK : SATURATED;
  }
};
